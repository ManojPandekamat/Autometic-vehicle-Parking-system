#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdbool.h>

// LCD Module connections
#define LCD_DATA PORTD
#define LCD_CTRL PORTB
#define RS PB0
#define RW PB1
#define EN PB2

int SlotArray[2]={0,0};



// Function prototypes
void lcd_command(unsigned char cmnd);
void lcd_data(unsigned char data);
void lcd_init(void);
void lcd_gotoxy(unsigned char x, unsigned char y);
void lcd_print(char* str);
void lcd_clear(void);
void rotate_servo();
void rotate_servo2();


unsigned int curr=0;
// global
int slot = 2; // parking slots in the area

int returnslot(){
	for(int i=0;i<2;i++){
		if(SlotArray[i]==0){
			SlotArray[i]=1;
			return i;
		}
	}
	return -1;
}

void MakeEmpty(unsigned int curr){
	if(curr==0)
	{
		SlotArray[0]=0;
		SlotArray[1]=0;
	}
	else if(curr=0x01){
		SlotArray[0]=1;
		SlotArray[1]=0;
	}
	else if(curr==0x02){
		SlotArray[0]=0;
		SlotArray[1]=1;
	}
	else if(curr==0x03){
		SlotArray[0]=1;
		SlotArray[1]=1;
	}
}

int main(void)
{
	DDRD = 0xFF;           // LCD data port as output
	DDRB = 0xFF;           // LCD control port as output
	//DDRA &= ~(1<<PA0);     // Left IR sensor input
	//DDRA &= ~(1<<PA1);     // Right IR sensor input
	DDRA=0xC0;
	//servo
	DDRC = 0x00; //Makes RC0 output pin
	//DDRC = 0x02;
	PORTC = 0x00;
	PORTA = 0x00;
	


	char str[] = "Car_Parking";
	char str2[] = "System";

	lcd_init();            // Initialize LCD
	lcd_clear();
	lcd_gotoxy(0, 0);
	lcd_print(str);
	lcd_gotoxy(6, 1);
	lcd_print(str2);
	_delay_ms(2000);
	int x = slot;
	char buffer[16];
	char buffer2[16]="Thank You";
	uint8_t left_sensor_triggered = 0;
	uint8_t right_sensor_triggered = 0;

	while (1)
	{
		// Check if left IR sensor is triggered
		if(x > 0){
			if ((PINA & (1<<PA0)) && !left_sensor_triggered)
			{

					x--;               // Decrement x
					left_sensor_triggered = 1;  // Set flag to indicate sensor has been triggered
					// Clear LCD and print updated value of x
					//---------------------------
					int returnedSlot=returnslot();
					lcd_clear();
					lcd_gotoxy(0, 0);
					sprintf(buffer, "Alloted : %d", returnedSlot);
					lcd_print(buffer);
					//---------------------------
					_delay_ms(500);    // Debounce delay
					rotate_servo();
			}
			else if (!(PINA & (1<<PA0)))  // Reset flag if sensor is not triggered
			{
				left_sensor_triggered = 0;
			}
			_delay_ms(1000);

		}

		// Check if right IR sensor is triggered
		if(x < slot){

			//return_slot
			if ((PINA & (1<<PA1)) && !right_sensor_triggered)
			{
				
					x++;               // Increment x
					right_sensor_triggered = 1; // Set flag to indicate sensor has been triggered
						lcd_clear();
						lcd_gotoxy(0, 0);
						lcd_print(buffer2);
						curr=PINC;
					_delay_ms(500);    // Debounce delay
					rotate_servo();

					MakeEmpty(curr);
				
			}
			else if (!(PINA & (1<<PA1)))  // Reset flag if sensor is not triggered
			{
				right_sensor_triggered = 0;
			}
		}

		// Clear LCD and print updated value of x
		lcd_clear();
		lcd_gotoxy(0, 0);
		sprintf(buffer, "Available : %d", x);
		lcd_print(buffer);
		_delay_ms(500);    // Debounce delay
	}
	return 0;
}

void lcd_command(unsigned char cmnd)
{
	LCD_DATA = cmnd;
	LCD_CTRL &= ~(1<<RS);  // RS = 0 for command
	LCD_CTRL &= ~(1<<RW);  // RW = 0 for write
	LCD_CTRL |= (1<<EN);   // Enable pulse
	_delay_us(1);
	LCD_CTRL &= ~(1<<EN);
	_delay_ms(3);
}

void lcd_data(unsigned char data)
{
	LCD_DATA = data;
	LCD_CTRL |= (1<<RS);   // RS = 1 for data
	LCD_CTRL &= ~(1<<RW);  // RW = 0 for write
	LCD_CTRL |= (1<<EN);   // Enable pulse
	_delay_us(1);
	LCD_CTRL &= ~(1<<EN);
	_delay_ms(1);
}

void lcd_init(void)
{
	LCD_CTRL = 0xFF;
	_delay_ms(20);

	lcd_command(0x38);  // Initialization of 16x2 LCD in 8-bit mode
	lcd_command(0x0C);  // Display on, cursor off
	lcd_command(0x06);  // Increment cursor (shift cursor to right)
	lcd_command(0x01);  // Clear display screen
	_delay_ms(2);
}

void lcd_gotoxy(unsigned char x, unsigned char y)
{
	unsigned char firstCharAddr[] = {0x80, 0xC0, 0x94, 0xD4};
	lcd_command(firstCharAddr[y] + x);
	_delay_us(100);
}

void lcd_print(char* str)
{
	unsigned char i = 0;
	while (str[i] != 0)
	{
		lcd_data(str[i]);
		i++;
	}
}

void lcd_clear(void)
{
	lcd_command(0x01);  // Clear display
	_delay_ms(2);
}
void rotate_servo(){
	PORTA = 0x80;
	_delay_us(2000);
	PORTA = 0x00;

	_delay_ms(2000);

	//Rotate Motor to 90 degree
	PORTA = 0x80;
	_delay_us(1000);
	PORTA = 0x00;

	//_delay_ms(2000);
}
void rotate_servo2(){
	PORTA = 0x40;
	_delay_us(2000);
	PORTA = 0x00;

	_delay_ms(2000);

	//Rotate Motor to 90 degree
	PORTA = 0x40;
	_delay_us(1000);
	PORTA = 0x00;

	//_delay_ms(2000);
}